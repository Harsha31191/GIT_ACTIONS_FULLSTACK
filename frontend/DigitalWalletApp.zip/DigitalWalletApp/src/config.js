// Backend API configuration
const config = {
  backendUrl: "http://localhost:9090/springbootdigitalwalletapi" // Change this to your backend URL
};

export default config;





